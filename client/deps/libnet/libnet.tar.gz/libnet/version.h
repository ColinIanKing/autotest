/*
 *  $Id: version.h.in,v 1.1.1.1 2003/06/26 21:55:10 route Exp $
 *  version.h.  Generated from version.h.in by configure.
 */

#define VERSION "1.1.2.1"
